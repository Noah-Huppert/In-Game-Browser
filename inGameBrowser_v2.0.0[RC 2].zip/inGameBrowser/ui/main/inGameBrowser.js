console.log($('#uberbar'));
window.test = "In Game Browser Can Be Global";
