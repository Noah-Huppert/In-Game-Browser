function injectInGameBrowser() {
	loadScript("coui://ui/main/uberbar/js/inGameBrowser2.js");
	loadCSS("coui://ui/main/uberbar/css/inGameBrowser2.css");
}

injectInGameBrowser();
